"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { register } from "../actions"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const courses = ["Computer Science", "Electronics", "Mechanical", "Civil"]

export default function Register() {
  const router = useRouter()
  const [error, setError] = useState("")
  const [course, setCourse] = useState("")

  async function handleSubmit(formData: FormData) {
    const result = await register(formData)
    if (result.error) {
      setError(result.error)
    } else {
      router.push("/login")
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center auth-background">
      <div className="bg-white/90 backdrop-blur-sm p-8 rounded-xl shadow-lg w-[400px] space-y-6">
        <h1 className="text-3xl font-bold text-center mb-6">Student Registration</h1>
        <form action={handleSubmit} className="space-y-4">
          <div>
            <Input
              name="name"
              placeholder="Student Name"
              required
              className="w-full bg-white/80 border-gray-200 focus:border-[#76C893]"
            />
          </div>
          <div>
            <Select name="course" value={course} onValueChange={setCourse} required>
              <SelectTrigger className="bg-white/80 border-gray-200 focus:border-[#76C893]">
                <SelectValue placeholder="Select Course" />
              </SelectTrigger>
              <SelectContent>
                {courses.map((course) => (
                  <SelectItem key={course} value={course}>
                    {course}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Input
              name="branch"
              placeholder="Branch"
              required
              className="w-full bg-white/80 border-gray-200 focus:border-[#76C893]"
            />
          </div>
          <div>
            <Input
              name="university"
              placeholder="University"
              required
              className="w-full bg-white/80 border-gray-200 focus:border-[#76C893]"
            />
          </div>
          <div>
            <Input
              name="email"
              type="email"
              placeholder="Email"
              required
              className="w-full bg-white/80 border-gray-200 focus:border-[#76C893]"
            />
          </div>
          <div>
            <Input
              name="password"
              type="password"
              placeholder="Create Password"
              required
              className="w-full bg-white/80 border-gray-200 focus:border-[#76C893]"
            />
          </div>
          <div>
            <Input
              name="confirmPassword"
              type="password"
              placeholder="Confirm Password"
              required
              className="w-full bg-white/80 border-gray-200 focus:border-[#76C893]"
            />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <Button type="submit" className="w-full bg-[#76C893] hover:bg-[#52B69A] h-12 text-lg font-medium">
            Register
          </Button>
        </form>
        <p className="mt-4 text-center">
          Already have an account?{" "}
          <Link href="/login" className="text-[#76C893] hover:underline">
            Login here
          </Link>
        </p>
      </div>
    </div>
  )
}

