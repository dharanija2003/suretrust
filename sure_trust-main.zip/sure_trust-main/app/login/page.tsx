"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { login } from "../actions"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { EyeIcon, EyeOffIcon } from "lucide-react"

export default function Login() {
  const router = useRouter()
  const [error, setError] = useState("")
  const [showPassword, setShowPassword] = useState(false)

  async function handleSubmit(formData: FormData) {
    const result = await login(formData)
    if (result.error) {
      setError(result.error)
    } else {
      router.push("/dashboard")
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center auth-background">
      <div className="bg-white/90 backdrop-blur-sm p-8 rounded-xl shadow-lg w-[400px] space-y-6">
        <h1 className="text-3xl font-bold text-center mb-2">Welcome to</h1>
        <h2 className="text-2xl font-bold text-center mb-6">SURE Trust</h2>
        <form action={handleSubmit} className="space-y-4">
          <div>
            <Input
              name="email"
              placeholder="21121A3522"
              required
              className="w-full bg-white/80 border-gray-200 focus:border-[#76C893]"
            />
          </div>
          <div className="relative">
            <Input
              name="password"
              type={showPassword ? "text" : "password"}
              placeholder="Password"
              required
              className="w-full pr-10 bg-white/80"
            />
            <button
              type="button"
              className="absolute right-3 top-1/2 -translate-y-1/2"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? (
                <EyeOffIcon className="h-5 w-5 text-gray-500" />
              ) : (
                <EyeIcon className="h-5 w-5 text-gray-500" />
              )}
            </button>
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <Button type="submit" className="w-full bg-[#76C893] hover:bg-[#52B69A] h-12 text-lg font-medium">
            Login
          </Button>
        </form>
        <p className="mt-4 text-center">
          Don&apos;t have an account?{" "}
          <Link href="/register" className="text-[#76C893] hover:underline">
            Register here
          </Link>
        </p>
      </div>
    </div>
  )
}

