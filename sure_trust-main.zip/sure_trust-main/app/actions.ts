"use server"

import { connectToDatabase } from "@/lib/db"
import User from "@/models/user"
import { hash, compare } from "bcryptjs"

export async function register(formData: FormData) {
  try {
    await connectToDatabase()

    const name = formData.get("name") as string
    const email = formData.get("email") as string
    const password = formData.get("password") as string
    const confirmPassword = formData.get("confirmPassword") as string
    const course = formData.get("course") as string
    const branch = formData.get("branch") as string
    const university = formData.get("university") as string

    if (password !== confirmPassword) {
      return { error: "Passwords do not match" }
    }

    const existingUser = await User.findOne({ email })
    if (existingUser) {
      return { error: "Email already exists" }
    }

    const hashedPassword = await hash(password, 12)

    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      course,
      branch,
      university,
    })

    return { success: true }
  } catch (error) {
    return { error: "Something went wrong" }
  }
}

export async function login(formData: FormData) {
  try {
    await connectToDatabase()

    const email = formData.get("email") as string
    const password = formData.get("password") as string

    const user = await User.findOne({ email })
    if (!user) {
      return { error: "User not found" }
    }

    const isValid = await compare(password, user.password)
    if (!isValid) {
      return { error: "Invalid password" }
    }

    return { success: true }
  } catch (error) {
    return { error: "Something went wrong" }
  }
}

